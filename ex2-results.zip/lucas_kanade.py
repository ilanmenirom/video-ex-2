import cv2
import numpy as np
from tqdm import tqdm
from scipy import signal
from scipy.interpolate import griddata


# FILL IN YOUR ID
ID1 = 206784514
ID2 = 204326250


PYRAMID_FILTER = 1.0 / 256 * np.array([[1, 4, 6, 4, 1],
                                       [4, 16, 24, 16, 4],
                                       [6, 24, 36, 24, 6],
                                       [4, 16, 24, 16, 4],
                                       [1, 4, 6, 4, 1]])
X_DERIVATIVE_FILTER = np.array([[1, 0, -1],
                                [2, 0, -2],
                                [1, 0, -1]])
Y_DERIVATIVE_FILTER = X_DERIVATIVE_FILTER.copy().transpose()

WINDOW_SIZE = 5


def get_video_parameters(capture: cv2.VideoCapture) -> dict:
    """Get an OpenCV capture object and extract its parameters.

    Args:
        capture: cv2.VideoCapture object.

    Returns:
        parameters: dict. Video parameters extracted from the video.

    """
    fourcc = int(capture.get(cv2.CAP_PROP_FOURCC))
    fps = int(capture.get(cv2.CAP_PROP_FPS))
    height = int(capture.get(cv2.CAP_PROP_FRAME_HEIGHT))
    width = int(capture.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_count = int(capture.get(cv2.CAP_PROP_FRAME_COUNT))
    return {"fourcc": fourcc, "fps": fps, "height": height, "width": width,
            "frame_count": frame_count}


def build_pyramid(image: np.ndarray, num_levels: int) -> list[np.ndarray]:
    """Coverts image to a pyramid list of size num_levels.

    First, create a list with the original image in it. Then, iterate over the
    levels. In each level, convolve the PYRAMID_FILTER with the image from the
    previous level. Then, decimate the result using indexing: simply pick
    every second entry of the result.
    Hint: Use signal.convolve2d with boundary='symm' and mode='same'.

    Args:
        image: np.ndarray. Input image.
        num_levels: int. The number of blurring / decimation times.

    Returns:
        pyramid: list. A list of np.ndarray of images.

    Note that the list length should be num_levels + 1 as the in first entry of
    the pyramid is the original image.
    You are not allowed to use cv2 PyrDown here (or any other cv2 method).
    We use a slightly different decimation process from this function.
    """
    pyramid = [image.copy()]
    for _ in range(num_levels):
        prev_img = pyramid[-1]
        filtered = signal.convolve2d(prev_img, PYRAMID_FILTER, boundary='symm', mode='same')
        decimated = filtered[::2, ::2].copy()
        pyramid.append(decimated)
    return pyramid


def lucas_kanade_step(I1: np.ndarray,
                      I2: np.ndarray,
                      window_size: int) -> tuple[np.ndarray, np.ndarray]:
    """Perform one Lucas-Kanade Step.

    This method receives two images as inputs and a window_size. It
    calculates the per-pixel shift in the x-axis and y-axis. That is,
    it outputs two maps of the shape of the input images. The first map
    encodes the per-pixel optical flow parameters in the x-axis and the
    second in the y-axis.

    (1) Calculate Ix and Iy by convolving I2 with the appropriate filters (
    see the constants in the head of this file).
    (2) Calculate It from I1 and I2.
    (3) Calculate du and dv for each pixel:
      (3.1) Start from all-zeros du and dv (each one) of size I1.shape.
      (3.2) Loop over all pixels in the image (you can ignore boundary pixels up
      to ~window_size/2 pixels in each side of the image [top, bottom,
      left and right]).
      (3.3) For every pixel, pretend the pixel’s neighbors have the same (u,
      v). This means that for NxN window, we have N^2 equations per pixel.
      (3.4) Solve for (u, v) using Least-Squares solution. When the solution
      does not converge, keep this pixel's (u, v) as zero.
    For detailed Equations reference look at slides 4 & 5 in:
    http://www.cse.psu.edu/~rtc12/CSE486/lecture30.pdf

    Args:
        I1: np.ndarray. Image at time t.
        I2: np.ndarray. Image at time t+1.
        window_size: int. The window is of shape window_size X window_size.

    Returns:
        (du, dv): tuple of np.ndarray-s. Each one is of the shape of the
        original image. dv encodes the optical flow parameters in rows and du
        in columns.
    """
    
    Ix = signal.convolve2d(I2.astype(np.float64), X_DERIVATIVE_FILTER, mode='same')
    Iy = signal.convolve2d(I2.astype(np.float64), Y_DERIVATIVE_FILTER, mode='same')
    It = I2.astype(np.float64) - I1.astype(np.float64)
    du = np.zeros_like(I1, dtype=np.float64)
    dv = np.zeros_like(I1, dtype=np.float64)
    half_size = window_size // 2
    height, width = I1.shape

    for row in range(half_size, height - half_size):
        for col in range(half_size, width - half_size):
            region = (slice(row - half_size, row + half_size + 1), slice(col - half_size, col + half_size + 1))
            A = np.column_stack((Ix[region].ravel(), Iy[region].ravel()))
            b = -It[region].ravel()
            shift, _, rank, _ = np.linalg.lstsq(A, b, rcond=None)
            if rank == 2 and np.all(np.isfinite(shift)):
                du[row, col], dv[row, col] = shift
            # Else - du & dv remain 0
    
    return du, dv


def warp_image(image: np.ndarray, u: np.ndarray, v: np.ndarray) -> np.ndarray:
    """Warp image using the optical flow parameters in u and v.

    Note that this method needs to support the case where u and v shapes do
    not share the same shape as of the image. We will update u and v to the
    shape of the image. The way to do it, is to:
    (1) cv2.resize to resize the u and v to the shape of the image.
    (2) Then, normalize the shift values according to a factor. This factor
    is the ratio between the image dimension and the shift matrix (u or v)
    dimension (the factor for u should take into account the number of columns
    in u and the factor for v should take into account the number of rows in v).

    As for the warping, use `scipy.interpolate`'s `griddata` method. Define the
    grid-points using a flattened version of the `meshgrid` of 0:w-1 and 0:h-1.
    The values here are simply image.flattened().
    The points you wish to interpolate are, again, a flattened version of the
    `meshgrid` matrices - don't forget to add them v and u.
    Use `np.nan` as `griddata`'s fill_value.
    Finally, fill the nan holes with the source image values.
    Hint: For the final step, use np.isnan(image_warp).

    Args:
        image: np.ndarray. Image to warp.
        u: np.ndarray. Optical flow parameters corresponding to the columns.
        v: np.ndarray. Optical flow parameters corresponding to the rows.

    Returns:
        image_warp: np.ndarray. Warped image.
    """
    height, width = image.shape
    u_float, v_float = u.astype(np.float64), v.astype(np.float64)
    if u_float.shape != image.shape:
        scale_x = width / u_float.shape[1]
        u_float = cv2.resize(u_float, (width, height)) * scale_x
    if v_float.shape != image.shape:
        scale_y = height / v_float.shape[0]
        v_float = cv2.resize(v_float, (width, height)) * scale_y

    columns, rows = np.meshgrid(np.arange(width), np.arange(height))
    points = np.column_stack((columns.ravel(), rows.ravel()))
    samples = np.column_stack(((columns + u_float).ravel(), (rows + v_float).ravel()))
    image_warp = griddata(points, image.ravel(), samples, method='linear', fill_value=np.nan)
    image_warp = image_warp.reshape(image.shape)
    holes = np.isnan(image_warp)
    image_warp[holes] = image[holes]
    return image_warp


def lucas_kanade_optical_flow(I1: np.ndarray,
                              I2: np.ndarray,
                              window_size: int,
                              max_iter: int,
                              num_levels: int) -> tuple[np.ndarray, np.ndarray]:
    """Calculate LK Optical Flow for max iterations in num-levels.

    Args:
        I1: np.ndarray. Image at time t.
        I2: np.ndarray. Image at time t+1.
        window_size: int. The window is of shape window_size X window_size.
        max_iter: int. Maximal number of LK-steps for each level of the pyramid.
        num_levels: int. Number of pyramid levels.

    Returns:
        (u, v): tuple of np.ndarray-s. Each one of the shape of the
        original image. v encodes the optical flow parameters in rows and u in
        columns.

    Recipe:
        (1) Since the image is going through a series of decimations,
        we would like to resize the image shape to:
        K * (2^(num_levels)) X M * (2^(num_levels)).
        Where: K is the ceil(h / (2^(num_levels)),
        and M is ceil(h / (2^(num_levels)).
        (2) Build pyramids for the two images.
        (3) Initialize u and v as all-zero matrices in the shape of I1.
        (4) For every level in the image pyramid (start from the smallest
        image):
          (4.1) Warp I2 from that level according to the current u and v.
          (4.2) Repeat for num_iterations:
            (4.2.1) Perform a Lucas Kanade Step with the I1 decimated image
            of the current pyramid level and the current I2_warp to get the
            new I2_warp.
          (4.3) For every level which is not the image's level, perform an
          image resize (using cv2.resize) to the next pyramid level resolution
          and scale u and v accordingly.
    """
    original_height, original_width = I1.shape
    factor = 2 ** num_levels
    height = int(np.ceil(original_height / factor)) * factor
    width = int(np.ceil(original_width / factor)) * factor
    image_size = (width, height)
    I1_float, I2_float = I1.astype(np.float64), I2.astype(np.float64)
    if I1.shape != (height, width):
        I1_float = cv2.resize(I1.astype(np.float64), image_size)
        I2_float = cv2.resize(I2.astype(np.float64), image_size)

    pyramid_I1, pyramid_I2 = build_pyramid(I1_float, num_levels), build_pyramid(I2_float, num_levels)
    u, v = np.zeros_like(pyramid_I1[-1]), np.zeros_like(pyramid_I1[-1])

    # Run L-K iterations per level, starting from top level
    for level in range(num_levels, -1, -1):
        reference, source = pyramid_I1[level], pyramid_I2[level]
        # Preprocess (resize):
        if u.shape != reference.shape:
            next_height, next_width = reference.shape
            scale_x, scale_y = next_width / u.shape[1], next_height / v.shape[0]
            u = cv2.resize(u, (next_width, next_height)) * scale_x
            v = cv2.resize(v, (next_width, next_height)) * scale_y

        # Run L-K Iterations:
        for _ in range(max_iter):
            warped = warp_image(source, u, v)
            du, dv = lucas_kanade_step(reference, warped, window_size)
            u += du
            v += dv

    if u.shape != (original_height, original_width):
        u = cv2.resize(u, (original_width, original_height)) * (original_width / width)
        v = cv2.resize(v, (original_width, original_height)) * (original_height / height)

    return u, v


def lucas_kanade_video_stabilization(input_video_path: str,
                                     output_video_path: str,
                                     window_size: int,
                                     max_iter: int,
                                     num_levels: int) -> None:
    """Use LK Optical Flow to stabilize the video and save it to file.

    Args:
        input_video_path: str. path to input video.
        output_video_path: str. path to output stabilized video.
        window_size: int. The window is of shape window_size X window_size.
        max_iter: int. Maximal number of LK-steps for each level of the pyramid.
        num_levels: int. Number of pyramid levels.

    Returns:
        None.

    Recipe:
        (1) Open a VideoCapture object of the input video and read its
        parameters.
        (2) Create an output video VideoCapture object with the same
        parameters as in (1) in the path given here as input.
        (3) Convert the first frame to grayscale and write it as-is to the
        output video.
        (4) Resize the first frame as in the Full-Lucas-Kanade function to
        K * (2^(num_levels)) X M * (2^(num_levels)).
        Where: K is the ceil(h / (2^(num_levels)),
        and M is ceil(h / (2^(num_levels)).
        (5) Create a u and a v which are og the size of the image.
        (6) Loop over the frames in the input video (use tqdm to monitor your
        progress) and:
          (6.1) Resize them to the shape in (4).
          (6.2) Feed them to the lucas_kanade_optical_flow with the previous
          frame.
          (6.3) Use the u and v maps obtained from (6.2) and compute their
          mean values over the region that the computation is valid (exclude
          half window borders from every side of the image).
          (6.4) Update u and v to their mean values inside the valid
          computation region.
          (6.5) Add the u and v shift from the previous frame diff such that
          frame in the t is normalized all the way back to the first frame.
          (6.6) Save the updated u and v for the next frame (so you can
          perform step 6.5 for the next frame.
          (6.7) Finally, warp the current frame with the u and v you have at
          hand.
          (6.8) We highly recommend you to save each frame to a directory for
          your own debug purposes. Erase that code when submitting the exercise.
       (7) Do not forget to gracefully close all VideoCapture and to destroy
       all windows.
    """
    capture = cv2.VideoCapture(input_video_path)
    writer = None  # writer stays None for cases the input video isn't read properly
    try:
        if not capture.isOpened():
            raise ValueError(f"Cannot open input video: {input_video_path}")
        parameters = get_video_parameters(capture)
        success, first_frame = capture.read()
        if not success:
            raise ValueError("Input video capture read failed")
        first_frame = cv2.cvtColor(first_frame, cv2.COLOR_BGR2GRAY)  # convert to grayscale
        original_height, original_width = first_frame.shape
        output_size = (original_width, original_height)
        writer = cv2.VideoWriter(output_video_path, cv2.VideoWriter_fourcc(*'XVID'), capture.get(cv2.CAP_PROP_FPS), output_size, isColor=False)
        writer.write(first_frame)  # first output frame is the same as input

        factor = 2 ** num_levels
        height = int(np.ceil(original_height / factor)) * factor
        width = int(np.ceil(original_width / factor)) * factor
        working_size = (width, height)
        prev_frame = cv2.resize(first_frame, working_size).astype(np.float64)
        half = window_size // 2
        valid = (slice(half, height - half), slice(half, width - half))
        if height <= 2 * half or width <= 2 * half:
            raise ValueError("Video frames are smaller than the LK window")
        u = np.zeros((height, width))
        v = np.zeros((height, width))
        total_u, total_v = 0.0, 0.0

        for _ in tqdm(range(1, parameters['frame_count']), desc="Stabilizing video"):
            success, curr_frame = capture.read()
            # Frame preprocess:
            curr_frame = cv2.cvtColor(curr_frame, cv2.COLOR_BGR2GRAY)
            curr_frame = cv2.resize(curr_frame, working_size).astype(np.float64)  
            du, dv = lucas_kanade_optical_flow(
                prev_frame, curr_frame, window_size, max_iter, num_levels)
            # Mean translation per frame; accumulate in frame 1 coordinates.
            total_u += float(np.mean(du[valid]))
            total_v += float(np.mean(dv[valid]))
            u[valid] = total_u
            v[valid] = total_v
            stabilized = warp_image(curr_frame, u, v)
            if stabilized.shape != first_frame.shape:
                stabilized = cv2.resize(stabilized, output_size)
            
            writer.write(np.clip(stabilized, 0, 255).astype(np.uint8))  # write stabilized frame
            prev_frame = curr_frame  # next stabilization is relative to this frame

    finally:
        # Release captures and windows
        capture.release()
        if writer is not None:
            writer.release()
        cv2.destroyAllWindows()


def faster_lucas_kanade_step(I1: np.ndarray,
                             I2: np.ndarray,
                             window_size: int) -> tuple[np.ndarray, np.ndarray]:
    """Faster implementation of a single Lucas-Kanade Step.

    (1) If the image is small enough (you need to design what is good
    enough), simply return the result of the good old lucas_kanade_step
    function.
    (2) Otherwise, find corners in I2 and calculate u and v only for these
    pixels.
    (3) Return maps of u and v which are all zeros except for the corner
    pixels you found in (2).

    Args:
        I1: np.ndarray. Image at time t.
        I2: np.ndarray. Image at time t+1.
        window_size: int. The window is of shape window_size X window_size.

    Returns:
        (du, dv): tuple of np.ndarray-s. Each one of the shape of the
        original image. dv encodes the shift in rows and du in columns.
    """

    du = np.zeros(I1.shape)
    dv = np.zeros(I1.shape)
    """INSERT YOUR CODE HERE.
    Calculate du and dv correctly.
    """
    return du, dv


def faster_lucas_kanade_optical_flow(
        I1: np.ndarray, I2: np.ndarray, window_size: int, max_iter: int,
        num_levels: int) -> tuple[np.ndarray, np.ndarray]:
    """Calculate LK Optical Flow for max iterations in num-levels .

    Use faster_lucas_kanade_step instead of lucas_kanade_step.

    Args:
        I1: np.ndarray. Image at time t.
        I2: np.ndarray. Image at time t+1.
        window_size: int. The window is of shape window_size X window_size.
        max_iter: int. Maximal number of LK-steps for each level of the pyramid.
        num_levels: int. Number of pyramid levels.

    Returns:
        (u, v): tuple of np.ndarray-s. Each one of the shape of the
        original image. v encodes the shift in rows and u in columns.
    """
    h_factor = int(np.ceil(I1.shape[0] / (2 ** num_levels)))
    w_factor = int(np.ceil(I1.shape[1] / (2 ** num_levels)))
    IMAGE_SIZE = (w_factor * (2 ** num_levels),
                  h_factor * (2 ** num_levels))
    if I1.shape != IMAGE_SIZE:
        I1 = cv2.resize(I1, IMAGE_SIZE)
    if I2.shape != IMAGE_SIZE:
        I2 = cv2.resize(I2, IMAGE_SIZE)
    pyramid_I1 = build_pyramid(I1, num_levels)  # create levels list for I1
    pyarmid_I2 = build_pyramid(I2, num_levels)  # create levels list for I1
    u = np.zeros(pyarmid_I2[-1].shape)  # create u in the size of smallest image
    v = np.zeros(pyarmid_I2[-1].shape)  # create v in the size of smallest image
    """INSERT YOUR CODE HERE.
    Replace u and v with their true value."""
    u = np.zeros(I1.shape)
    v = np.zeros(I1.shape)
    return u, v


def lucas_kanade_faster_video_stabilization(
        input_video_path: str, output_video_path: str, window_size: int,
        max_iter: int, num_levels: int) -> None:
    """Calculate LK Optical Flow to stabilize the video and save it to file.

    Args:
        input_video_path: str. path to input video.
        output_video_path: str. path to output stabilized video.
        window_size: int. The window is of shape window_size X window_size.
        max_iter: int. Maximal number of LK-steps for each level of the pyramid.
        num_levels: int. Number of pyramid levels.

    Returns:
        None.
    """
    """INSERT YOUR CODE HERE."""
    pass


def lucas_kanade_faster_video_stabilization_fix_effects(
        input_video_path: str, output_video_path: str, window_size: int,
        max_iter: int, num_levels: int, start_rows: int = 10,
        start_cols: int = 2, end_rows: int = 30, end_cols: int = 30) -> None:
    """Calculate LK Optical Flow to stabilize the video and save it to file.

    Args:
        input_video_path: str. path to input video.
        output_video_path: str. path to output stabilized video.
        window_size: int. The window is of shape window_size X window_size.
        max_iter: int. Maximal number of LK-steps for each level of the pyramid.
        num_levels: int. Number of pyramid levels.
        start_rows: int. The number of lines to cut from top.
        end_rows: int. The number of lines to cut from bottom.
        start_cols: int. The number of columns to cut from left.
        end_cols: int. The number of columns to cut from right.

    Returns:
        None.
    """
    """INSERT YOUR CODE HERE."""
    pass


